# Example Python Code to Insert a Document

from pymongo import MongoClient
from bson.objectid import ObjectId


class AnimalShelter(object):
    """ CRUD operations for Animal collection in MongoDB """

    def __init__(self, username, password):
        # Initializing the MongoClient. This helps to access the MongoDB
        # databases and collections. This is hard-wired to use the aac
        # database, the animals collection, and the aac user.
        #
        # You must edit the password below for your environment.

        # Connection Variables
        USER = username
        PASS = password
        HOST = 'localhost'
        PORT = 27017
        DB = 'aac'
        COL = 'animals'

              # Initialize Connection
        self.client = MongoClient(
            host=HOST,
            port=PORT,
            username=USER,
            password=PASS,
            authSource='admin',
            serverSelectionTimeoutMS=5000
        )

        # Check the connection and supplied credentials.
        self.client.admin.command('ping')

        self.database = self.client[DB]
        self.collection = self.database[COL]
    # Create a method to return the next available record number for use
    # in the create method

    # Complete this create method to implement the C in CRUD.
    def create(self, data):
        if data is not None:
            try:
                self.database.animals.insert_one(data)
                return True
            except Exception as e:
                print("Error inserting document:", e)
                return False
        else:
            return False

    # Create method to implement the R in CRUD.
    def read(self, query):
        if query is not None:
            try:
                documents = self.collection.find(query)
                return list(documents)
            except Exception as e:
                print("Error reading documents:", e)
                return []
        else:
            return []
            # Create method to implement the U in CRUD.
    def update(self, query, new_values):
        if query and new_values:
            try:
                result = self.collection.update_many(
                    query, {"$set": new_values}
                )
                return result.modified_count
            except Exception as e:
                print("Error updating documents:", e)
                return 0
        else:
            return 0

    # Create method to implement the D in CRUD.
    def delete(self, query):
        if query:
            try:
                result = self.collection.delete_many(query)
                return result.deleted_count
            except Exception as e:
                print("Error deleting documents:", e)
                return 0
        else:
            return 0